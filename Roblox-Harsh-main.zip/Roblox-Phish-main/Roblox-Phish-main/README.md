# Roblox-Phish

**• Una herramienta de phishing hecha solo para roblox con su pagina de inicio de sesion.**

**• No me hago resposable del mal uso que se le pueda dar a esta herramienta es bajo su propia responsabilidad**

**• Creditos de la pagina:** **[KasRoudra](https://github.com/KasRoudra)**

**• Page credits:** [KasRoudra](https://github.com/KasRoudra)

# Repository review:
- [Uso e Instalacion (Español / Spanish](https://github.com/Euronymou5/Roblox-Phish/blob/main/README.md#uso-e-instalacion)
- [Requiremientos (Español / Spanish)](https://github.com/Euronymou5/Roblox-Phish#requiremientos)
- [Sistemas operativos compatibles (Español / Spanish)](https://github.com/Euronymou5/Roblox-Phish#sistemas-operativos-compatibles)
- [English Repo](https://github.com/Euronymou5/Roblox-Phish#roblox-phish-1)
- [Installation and use](https://github.com/Euronymou5/Roblox-Phish#installation-and-use)
- [Requirements](https://github.com/Euronymou5/Roblox-Phish#requirements)
- [Supported operating systems](https://github.com/Euronymou5/Roblox-Phish#supported-operating-systems)
- [Imagenes / Images](https://github.com/Euronymou5/Roblox-Phish#imagenes--images)


# Uso e Instalacion:

## Requiremientos:

  **Python3**
  
  **PHP**

## Sistemas operativos compatibles:
   **Linux (Debian) : ✔️**
   
   **Andorid (Termux): ❌**
   
   **Windows: ❌** **Con windows se puede usar [CloudShell](https://cloud.google.com/shell?hl=es)**

```bash
git clone https://github.com/Euronymou5/Roblox-Phish
```
```bash
cd Roblox-Phish
```
```
python3 main.py
```

--------

# Roblox-Phish

**• A phishing tool made just for roblox with its login page.**

**• I am not responsible for the misuse that may be given to this tool, it is at your own risk.**

# Installation and Use:

## Requirements:

  **Python3**
  
  **PHP**
  
## Supported operating systems:
   **Linux (Debian) : ✔️**
   
   **Andorid (Termux): ❌**
   
   **Windows: ❌** **With windows it can be used [CloudShell](https://cloud.google.com/shell?hl=es)**
   
```bash
git clone https://github.com/Euronymou5/Roblox-Phish
```
```bash
cd Roblox-Phish
```
```
python3 main.py
```

# Imagenes / Images:

| Spanish Version | English Version |	
| -------------- | ---------------------- |   
|![Index](https://media.discordapp.net/attachments/797338700596904018/1049115047294672936/image.png?width=881&height=431)|![f](https://media.discordapp.net/attachments/995599976463859713/1049440632399204442/image.png?width=874&height=431)


# Contacto / Contact:

**Discord:** **Euronymou5#3155**
